# V6 Combined BOS + CHoCH Visual Examination — Master Prompt

Analyze each supplied synthetic OHLC candlestick chart independently. Mark BOTH BOS and CHoCH where supported by the approved V6 experimental rules. Candle indices are 1-based.

## Approved rules
- Swing baseline: fixed L=2, R=2; strict comparisons for unique pivots; equal highs/lows are not unique pivots; one candle may independently be both swing high and swing low.
- A swing is confirmed only after two right-side candles close. No look-ahead.
- BOS is direction-independent from market-structure state (Option A). It requires a candle CLOSE beyond the most recent eligible confirmed swing level. Wick-only is not BOS. Mark at break candle close. Do not duplicate a BOS for repeated crossings of the same reference swing.
- External structure only for CHoCH. Bullish structure uses HH+HL; bearish structure uses LH+LL. If insufficient evidence, label structure UNKNOWN.
- CHoCH candidate requires a candle CLOSE beyond the relevant protected swing. Wick-only is NO_CHOCH — WICK_ONLY evidence, not a CHoCH event.
- After CHoCH, state becomes TRANSITION; do not declare a full reversal or emit repeated CHoCH while transition lock is active.

## Do not guess unresolved rules
Protected-swing lifecycle/association, exact initial-structure chronology, failed-CHoCH sequencing, complex multi-level breaks, same-candle ordering, history/session gaps, event invalidation/IDs, and transition completion remain unresolved. If an event depends on one of these, mark UNRESOLVED / DO NOT SCORE and explain why. Never silently invent a rule.

## Required per-chart output
1. Annotated chart: BOS blue level/arrow and `BOS ↑/↓`; CHoCH red protected level/arrow and `CHoCH ↑/↓`; wick-only rejected candidates dashed orange; UNKNOWN/unresolved grey marker.
2. Event table: `event_id | type | direction | reference_level | reference_swing_index | break_candle_index | close_or_wick | structure_before | state_after | confidence | rationale`.
3. List confirmed swing highs/lows (index, price), HH/LH and HL/LL comparisons, and when external structure first becomes established or why UNKNOWN.
4. Separate confirmed events, candidates, wick-only rejections, and unresolved cases.

## Discipline
- Do not infer protected swing merely because it is the latest HL/LH; explain the BOS association if used.
- Do not count wick as close. Do not require established trend for BOS.
- Same-direction BOS is not CHoCH. CHoCH is not confirmed reversal; immediate state is TRANSITION.
- If no event is supported, state `NO VALID BOS / CHoCH`.
- Do not use indicators, volume, news, or outside assumptions. Do not claim code execution or detector results.
- Do not modify source images or production code, V4, scanner logic, or repository files.

## Final 12-chart summary
Count confirmed BOS, confirmed CHoCH, wick-only rejections, and UNKNOWN/unscored candidates. Give per-chart pass/fail and flag unclear chart readings. Do not access an answer key.
