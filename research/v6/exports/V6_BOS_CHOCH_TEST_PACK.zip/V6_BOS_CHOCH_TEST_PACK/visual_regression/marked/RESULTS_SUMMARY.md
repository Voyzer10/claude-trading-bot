# V6 BOS + CHoCH retest: results summary (Phase 4, 22 Nov 2026)

Research only, PAPER ONLY. No answer key was used or created.

- **Detector:** the V6 detector on branch `research/v6-smc-scanner` (HEAD `7f16f09` + uncommitted work):
  - `scanner_v6/structure/swings.py`, `bos.py`, `protected_levels.py`, `choch.py`.
  - Every marking on the PNGs comes from its output, not from a hand-typed list.
- **Rules applied:**
  - approved swing profile (L2/R2, strict, equal levels not swings)
  - BOS-001…005 and Option A
  - A1–A10
  - owner decisions of 22 Nov 2026: D1, D2 (P-B, protected only after confirmation), D3 (X1 with COMPLEX guard), D4 (latest confirmed reference), D5 (same-candle order)
- **Not all CHoCH rules are final.** O4, O7, O8, O9, CHU04 and CHU05 remain unresolved. None of them affects this pack: no O4 or O9 diagnostic fired on any of the 12 charts.
- **Expected values** come from `research/v6/specs/choch_v0_9/PHASE1_2_DECISIONS.md` §8. They were derived from the rules **before** the implementation.

## Per-chart expected vs actual

| Chart (file) | Expected BOS | Actual BOS | Expected CHoCH | Actual CHoCH | Wick-only (exp / act) | Final state (exp / act) | Result |
|---|---|---|---|---|---|---|---|
| V6_Easy_BOS_CHOCH_Chart_1.png | ↓ c19 | ↓ c19 | none | none | – / – | UNKNOWN / UNKNOWN | **PASS** |
| V6_Easy_BOS_CHOCH_Chart_2.png | ↓ c8, ↓ c13 | ↓ c8, ↓ c13 | none | none | – / – | BEARISH / BEARISH | **PASS** |
| V6_Easy_BOS_CHOCH_Chart_3.png | ↑ c16 | ↑ c16 | none | none | – / – | UNKNOWN / UNKNOWN | **PASS** |
| V6_Medium_BOS_CHOCH_Chart_1.png | ↑ c8, ↑ c12, ↑ c16, ↓ c19 | ↑ c8, ↑ c12, ↑ c16, ↓ c19 | ↓ c19 (108.74) | ↓ c19 (108.74) | – / – | TRANSITION(bearish) / TRANSITION(bearish) | **PASS** |
| V6_Medium_BOS_CHOCH_Chart_2.png | ↓ c13 | ↓ c13 | none | none | – / – | UNKNOWN / UNKNOWN | **PASS** |
| V6_Medium_BOS_CHOCH_Chart_3.png | ↑ c8, ↑ c12, ↑ c16, ↑ c20 | ↑ c8, ↑ c12, ↑ c16, ↑ c20 | none | none | – / – | BULLISH / BULLISH | **PASS** |
| V6_Hard_BOS_CHOCH_Chart_1.png | ↑ c8, ↑ c12, ↓ c16 | ↑ c8, ↑ c12, ↓ c16 | ↓ c16 (310.41; crossed 307.47) | ↓ c16 (310.41; crossed 307.47) | [15] / [15] | TRANSITION(bearish) / TRANSITION(bearish) | **PASS** |
| V6_Hard_BOS_CHOCH_Chart_2.png | ↓ c13 | ↓ c13 | none | none | – / – | BEARISH / BEARISH | **PASS** |
| V6_Hard_BOS_CHOCH_Chart_3.png | ↑ c8, ↑ c12, ↓ c15 | ↑ c8, ↑ c12, ↓ c15 | ↓ c15 (86.54) | ↓ c15 (86.54) | – / – | TRANSITION(bearish) / TRANSITION(bearish) | **PASS** |
| V6_Extreme_BOS_CHOCH_Chart_1.png | ↑ c8, ↑ c12, ↓ c16 | ↑ c8, ↑ c12, ↓ c16 | ↓ c16 (714.92; crossed 711.19) | ↓ c16 (714.92; crossed 711.19) | [15] / [15] | TRANSITION(bearish) / TRANSITION(bearish) | **PASS** |
| V6_Extreme_BOS_CHOCH_Chart_2.png | ↓ c8, ↓ c13 | ↓ c8, ↓ c13 | none | none | – / – | UNKNOWN / UNKNOWN | **PASS** |
| V6_Extreme_BOS_CHOCH_Chart_3.png | ↑ c8, ↑ c12, ↓ c15 | ↑ c8, ↑ c12, ↓ c15 | ↓ c15 (111.05) | ↓ c15 (111.05) | – / – | TRANSITION(bearish) / TRANSITION(bearish) | **PASS** |

**Totals (actual):** 28 BOS · 5 CHoCH (bearish) · 2 wick-only rejections · 0 COMPLEX_STRUCTURE_BREAK · 0 reversals confirmed · 0 C3-dependent BOS.

**12 / 12 charts match the spec-derived expectation.**

## Sequence checks (D1 / D5)

- Every CHoCH candle also carries a same-direction BOS: Medium 1 c19, Hard 1 c16, Hard 3 c15, Extreme 1 c16, Extreme 3 c15.
  - In each case the state after the candle is **TRANSITION(bearish)**: the same-candle BOS did not confirm the reversal.
  - No later bearish BOS occurs in any of these charts (no new swing low forms), so **no reversal is confirmed**. The state stays TRANSITION to the end of the chart.
  - The full CHoCH → TRANSITION → separate BOS → confirmed sequence is covered by the synthetic fixtures CHD10 (bearish) and CHD11 (bullish) in the test suite.
- **P-B activation** (protected swing activated at the close shown):
  - Medium 1: 106.81 at c12 → 108.74 at c17
  - Hard 1: 310.41 at c13; Hard 3: 86.54 at c13
  - Extreme 1: 714.92 at c13; Extreme 3: 111.05 at c13
  - Each is the origin of its BOS, which confirmed after that BOS's close.
- **Complex breaks:**
  - Hard 1 c16 and Extreme 1 c16 close beyond the protected level and one non-protected level.
  - That is D3 X1: a single CHoCH, with `levels_crossed` = 307.47 / 711.19.
  - No COMPLEX case occurs.
- **UNKNOWN structure:** Easy 1, Easy 3, Medium 2 and Extreme 2 (fewer than 2 swing highs, mostly because equal highs are not swings). No CHoCH is possible there, but their BOS still count (Option A).

## Swings per chart (kind, candle, confirmed at candle, price)

- `V6_Easy_BOS_CHOCH_Chart_1.png`: low c7 (conf c9) 103.26, low c11 (conf c13) 103.69, low c15 (conf c17) 105.02, high c17 (conf c19) 113.53. Equal levels (not swings): high 109.99 at c4/c5, high 110.99 at c8/c9, high 111.99 at c12/c13.
- `V6_Easy_BOS_CHOCH_Chart_2.png`: low c5 (conf c7) 110.01, high c7 (conf c9) 117.14, low c9 (conf c11) 108.36, high c11 (conf c13) 116.14. Equal levels (not swings): none.
- `V6_Easy_BOS_CHOCH_Chart_3.png`: low c7 (conf c9) 52.99, high c8 (conf c10) 61.3, low c11 (conf c13) 54.27, low c15 (conf c17) 54.79, low c18 (conf c20) 56.31. Equal levels (not swings): high 59.84 at c4/c5, high 61.84 at c12/c13, high 62.84 at c16/c17.
- `V6_Medium_BOS_CHOCH_Chart_1.png`: high c4 (conf c6) 113.27, low c6 (conf c8) 105.02, high c8 (conf c10) 115.27, low c10 (conf c12) 106.81, high c12 (conf c14) 117.27, low c15 (conf c17) 108.74, high c16 (conf c18) 119.27. Equal levels (not swings): none.
- `V6_Medium_BOS_CHOCH_Chart_2.png`: low c4 (conf c6) 186.94, high c6 (conf c8) 197.2, low c8 (conf c10) 185.13. Equal levels (not swings): high 195.42 at c10/c11.
- `V6_Medium_BOS_CHOCH_Chart_3.png`: high c5 (conf c7) 73.3, low c6 (conf c8) 64.79, high c8 (conf c10) 75.12, low c11 (conf c13) 67.03, high c12 (conf c14) 77.74, high c16 (conf c18) 79.12, low c19 (conf c21) 71.16, high c20 (conf c22) 81.12. Equal levels (not swings): low 68.89 at c14/c15.
- `V6_Hard_BOS_CHOCH_Chart_1.png`: high c4 (conf c6) 320.84, low c6 (conf c8) 307.47, high c8 (conf c10) 322.83, low c11 (conf c13) 310.41, high c12 (conf c14) 325.83. Equal levels (not swings): none.
- `V6_Hard_BOS_CHOCH_Chart_2.png`: low c4 (conf c6) 480.51, high c6 (conf c8) 492.7, low c8 (conf c10) 479.28, high c10 (conf c12) 492.63. Equal levels (not swings): none.
- `V6_Hard_BOS_CHOCH_Chart_3.png`: high c4 (conf c6) 96.4, low c6 (conf c8) 85.89, high c9 (conf c11) 98.74, low c11 (conf c13) 86.54, high c12 (conf c14) 101.68. Equal levels (not swings): none.
- `V6_Extreme_BOS_CHOCH_Chart_1.png`: high c4 (conf c6) 726.39, low c6 (conf c8) 711.19, high c8 (conf c10) 732.7, low c11 (conf c13) 714.92, high c12 (conf c14) 735.39. Equal levels (not swings): none.
- `V6_Extreme_BOS_CHOCH_Chart_2.png`: low c4 (conf c6) 874.1, high c7 (conf c9) 890.5, low c8 (conf c10) 869.79. Equal levels (not swings): high 887.26 at c10/c11.
- `V6_Extreme_BOS_CHOCH_Chart_3.png`: high c4 (conf c6) 122.96, low c7 (conf c9) 108.32, high c8 (conf c10) 128.24, low c11 (conf c13) 111.05, high c13 (conf c15) 131.6. Equal levels (not swings): none.

## Visual QA (automated plus an individual look at every chart)

| File | Labels | Label overlaps | Original candle pixels under labels | Leader-line pixels over candles |
|---|---|---|---|---|
| V6_Easy_BOS_CHOCH_Chart_1.png | 9 | 0 | 0 | 0 |
| V6_Easy_BOS_CHOCH_Chart_2.png | 7 | 0 | 0 | 0 |
| V6_Easy_BOS_CHOCH_Chart_3.png | 10 | 0 | 0 | 0 |
| V6_Medium_BOS_CHOCH_Chart_1.png | 13 | 0 | 0 | 0 |
| V6_Medium_BOS_CHOCH_Chart_2.png | 6 | 0 | 0 | 0 |
| V6_Medium_BOS_CHOCH_Chart_3.png | 14 | 0 | 0 | 0 |
| V6_Hard_BOS_CHOCH_Chart_1.png | 12 | 0 | 0 | 0 |
| V6_Hard_BOS_CHOCH_Chart_2.png | 6 | 0 | 0 | 0 |
| V6_Hard_BOS_CHOCH_Chart_3.png | 10 | 0 | 0 | 0 |
| V6_Extreme_BOS_CHOCH_Chart_1.png | 12 | 0 | 0 | 0 |
| V6_Extreme_BOS_CHOCH_Chart_2.png | 7 | 0 | 0 | 0 |
| V6_Extreme_BOS_CHOCH_Chart_3.png | 10 | 0 | 0 | 0 |

**Legend:**
- Blue: BOS, a line from the reference swing to the break candle.
- Red dashed line + circle: CHoCH at the protected level.
- Orange ring: wick tip of a wick-only rejection.
- Grey dashed: an equal level (not a swing), or `levels_crossed` evidence beside the candle.
- Every label has an opaque white box and a leader line. No label covers a candle, and no leader line crosses one.
